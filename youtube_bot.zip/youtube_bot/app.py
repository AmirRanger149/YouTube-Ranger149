import telebot
import requests
import os
from pytube import YouTube

# Replace YOUR_TELEGRAM_BOT_TOKEN with your bot's token
bot = telebot.TeleBot("6148978762:AAF75ZjpiZ8_-anUmMMoSKWh6GFhxJvjCHA")

# Handler for the /start command
@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Hello! Send me a YouTube video link to download.")

# Handler for messages containing a YouTube video link
@bot.message_handler(func=lambda message: 'youtube.com/watch?v=' in message.text)
def download_video(message):
    try:
        url = message.text
        yt = YouTube(url)
        video = yt.streams.filter(progressive=True, file_extension='mp4').order_by('resolution').desc().first()
        video.download()
        video_file = open(f"{video.default_filename}", 'rb')
        bot.send_video(message.chat.id, video_file)
        os.remove(f"{video.default_filename}")
    except Exception as e:
        bot.reply_to(message, f"Error: {e}")

# Start the bot
bot.polling()
